'use client'

import { useState, useRef, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Mic, MicOff, Camera, Upload, MapPin, Cloud, Leaf, Bug, Banknote, Phone, MessageCircle, Languages, Sun, CloudRain, Thermometer, Droplets, Wind, Eye, AlertTriangle, CheckCircle, Store, Navigation, BookOpen, Users, Calendar, TrendingUp, Sparkles, Zap, Heart, Star, Award, Shield, Globe, Headphones, Clock, ExternalLink, Download, FileText, CreditCard, Wheat, Sprout, TreePine, Brain, Lightbulb, Rocket, Trophy, Target, Bot, Wand2, Fingerprint, Settings } from 'lucide-react'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Progress } from '@/components/ui/progress'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'

const languages = [
  { code: 'hi', name: 'हिंदी', flag: '🇮🇳' },
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'te', name: 'తెలుగు', flag: '🇮🇳' },
  { code: 'ta', name: 'தமிழ்', flag: '🇮🇳' },
  { code: 'bn', name: 'বাংলা', flag: '🇧🇩' },
  { code: 'mr', name: 'मराठी', flag: '🇮🇳' },
  { code: 'gu', name: 'ગુજરાતી', flag: '🇮🇳' },
  { code: 'pa', name: 'ਪੰਜਾਬੀ', flag: '🇮🇳' },
  { code: 'kn', name: 'ಕನ್ನಡ', flag: '🇮🇳' }
]

const weatherData = {
  temperature: 28,
  humidity: 65,
  rainfall: 12,
  windSpeed: 8,
  condition: 'Partly Cloudy',
  forecast: [
    { day: 'Today', temp: 28, condition: 'Partly Cloudy', rain: 20 },
    { day: 'Tomorrow', temp: 30, condition: 'Sunny', rain: 5 },
    { day: 'Day 3', temp: 26, condition: 'Rainy', rain: 80 },
    { day: 'Day 4', temp: 29, condition: 'Cloudy', rain: 40 },
    { day: 'Day 5', temp: 31, condition: 'Sunny', rain: 10 }
  ]
}

const cropSuitability = [
  { crop: 'Rice', suitability: 85, reason: 'High humidity favorable' },
  { crop: 'Wheat', suitability: 45, reason: 'Too humid for optimal growth' },
  { crop: 'Cotton', suitability: 70, reason: 'Good temperature range' },
  { crop: 'Sugarcane', suitability: 90, reason: 'Excellent conditions' }
]

const governmentSchemes = [
  {
    id: 1,
    name: 'PM-KISAN Samman Nidhi 2024-25',
    description: 'Direct income support of ₹6000 per year to all landholding farmers',
    eligibility: 'All landholding farmers with valid Aadhaar',
    amount: '₹6,000/year',
    status: 'Active',
    deadline: '31 March 2025',
    type: 'current',
    benefits: ['₹2000 every 4 months', 'Direct bank transfer', 'No paperwork required'],
    documents: ['Aadhaar Card', 'Bank Account Details', 'Land Records'],
    applyUrl: 'https://pmkisan.gov.in'
  },
  {
    id: 2,
    name: 'Pradhan Mantri Fasal Bima Yojana 2024',
    description: 'Comprehensive crop insurance scheme protecting farmers against crop loss',
    eligibility: 'All farmers including sharecroppers and tenant farmers',
    amount: 'Up to ₹2,00,000 per hectare',
    status: 'Open',
    deadline: '31 December 2024',
    type: 'current',
    benefits: ['Premium subsidy up to 90%', 'Quick claim settlement', 'Coverage for all crops'],
    documents: ['Aadhaar Card', 'Bank Account', 'Land Documents', 'Sowing Certificate'],
    applyUrl: 'https://pmfby.gov.in'
  },
  {
    id: 3,
    name: 'Kisan Credit Card Plus 2024',
    description: 'Enhanced credit facility with digital features and lower interest rates',
    eligibility: 'Farmers with land records and good credit history',
    amount: 'Up to ₹5,00,000 at 4% interest',
    status: 'Active',
    deadline: 'Ongoing',
    type: 'current',
    benefits: ['4% interest rate', 'Digital KCC app', 'Insurance coverage included'],
    documents: ['Aadhaar Card', 'PAN Card', 'Land Records', 'Income Certificate'],
    applyUrl: 'https://kcc.gov.in'
  },
  {
    id: 4,
    name: 'Digital Agriculture Mission 2025',
    description: 'Upcoming scheme for digital transformation of agriculture with AI and IoT',
    eligibility: 'Progressive farmers and FPOs',
    amount: '₹50,000 subsidy for digital tools',
    status: 'Coming Soon',
    deadline: 'Launch: April 2025',
    type: 'future',
    benefits: ['AI-powered crop monitoring', 'IoT sensors subsidy', 'Digital marketplace access'],
    documents: ['Registration pending'],
    applyUrl: '#'
  },
  {
    id: 5,
    name: 'Organic Farming Incentive Scheme 2025',
    description: 'New scheme promoting organic farming with certification support',
    eligibility: 'Farmers willing to convert to organic farming',
    amount: '₹25,000 per hectare for 3 years',
    status: 'Upcoming',
    deadline: 'Launch: January 2025',
    type: 'future',
    benefits: ['Organic certification support', 'Premium market access', 'Training programs'],
    documents: ['To be announced'],
    applyUrl: '#'
  },
  {
    id: 6,
    name: 'Climate Resilient Agriculture 2024',
    description: 'Support for climate-smart farming practices and drought-resistant crops',
    eligibility: 'Farmers in drought-prone and climate-affected areas',
    amount: '₹40,000 per hectare',
    status: 'Active',
    deadline: '15 February 2025',
    type: 'current',
    benefits: ['Drought-resistant seeds', 'Water conservation support', 'Weather insurance'],
    documents: ['Aadhaar Card', 'Land Records', 'Climate Impact Certificate'],
    applyUrl: 'https://climate-agri.gov.in'
  }
]

const fertilizerShops = [
  { name: 'Agri Care Center', distance: '2.3 km', rating: 4.5, phone: '+91 98765 43210' },
  { name: 'Green Valley Fertilizers', distance: '3.1 km', rating: 4.2, phone: '+91 98765 43211' },
  { name: 'Farmer\'s Choice', distance: '4.5 km', rating: 4.7, phone: '+91 98765 43212' },
  { name: 'Krishi Seva Kendra', distance: '5.2 km', rating: 4.3, phone: '+91 98765 43213' }
]

// Multilingual responses
const getAIResponse = (message: string, language: string) => {
  const responses = {
    hi: [
      'मैं आपकी समस्या समझ गया हूं। कृपया अधिक जानकारी दें।',
      'यह एक सामान्य समस्या है। मैं आपको समाधान बताता हूं।',
      'आपकी फसल के लिए यह उपाय करें और परिणाम देखें।',
      'मिट्टी की जांच कराना जरूरी है। नजदीकी कृषि केंद्र से संपर्क करें।'
    ],
    en: [
      'I understand your problem. Please provide more details.',
      'This is a common issue. Let me suggest a solution.',
      'Try this remedy for your crop and observe the results.',
      'Soil testing is essential. Contact your nearest agriculture center.'
    ],
    kn: [
      'ನಾನು ನಿಮ್ಮ ಸಮಸ್ಯೆಯನ್ನು ಅರ್ಥಮಾಡಿಕೊಂಡಿದ್ದೇನೆ. ದಯವಿಟ್ಟು ಹೆಚ್ಚಿನ ವಿವರಗಳನ್ನು ನೀಡಿ.',
      'ಇದು ಸಾಮಾನ್ಯ ಸಮಸ್ಯೆ. ನಾನು ಪರಿಹಾರವನ್ನು ಸೂಚಿಸುತ್ತೇನೆ.',
      'ನಿಮ್ಮ ಬೆಳೆಗೆ ಈ ಪರಿಹಾರವನ್ನು ಪ್ರಯತ್ನಿಸಿ ಮತ್ತು ಫಲಿತಾಂಶಗಳನ್ನು ಗಮನಿಸಿ.',
      'ಮಣ್ಣಿನ ಪರೀಕ್ಷೆ ಅತ್ಯಗತ್ಯ. ನಿಮ್ಮ ಹತ್ತಿರದ ಕೃಷಿ ಕೇಂದ್ರವನ್ನು ಸಂಪರ್ಕಿಸಿ.'
    ],
    te: [
      'నేను మీ సమస్యను అర్థం చేసుకున్నాను. దయచేసి మరిన్ని వివరాలు ఇవ్వండి.',
      'ఇది సాధారణ సమస్య. నేను పరిష్కారం సూచిస్తాను.',
      'మీ పంటకు ఈ చికిత్సను ప్రయత్నించండి మరియు ఫలితాలను గమనించండి.',
      'మట్టి పరీక్ష అవసరం. మీ సమీప వ్యవసాయ కేంద్రాన్ని సంప్రదించండి.'
    ],
    ta: [
      'உங்கள் பிரச்சனையை நான் புரிந்துகொண்டேன். மேலும் விவரங்களை தரவும்.',
      'இது பொதுவான பிரச்சனை. நான் தீர்வு சொல்கிறேன்.',
      'உங்கள் பயிருக்கு இந்த தீர்வை முயற்சிக்கவும் மற்றும் முடிவுகளை கவனிக்கவும்.',
      'மண் பரிசோதனை அவசியம். உங்கள் அருகிலுள்ள வேளாண் மையத்தை தொடர்பு கொள்ளவும்.'
    ]
  }
  
  const langResponses = responses[language as keyof typeof responses] || responses.en
  return langResponses[Math.floor(Math.random() * langResponses.length)]
}

const getVoiceMessage = (language: string) => {
  const messages = {
    hi: 'मेरी फसल में पत्तियां पीली हो रही हैं',
    en: 'My crop leaves are turning yellow',
    kn: 'ನನ್ನ ಬೆಳೆಯ ಎಲೆಗಳು ಹಳದಿಯಾಗುತ್ತಿವೆ',
    te: 'నా పంట ఆకులు పసుపు రంగులోకి మారుతున్నాయి',
    ta: 'என் பயிர் இலைகள் மஞ்சளாக மாறுகின்றன',
    mr: 'माझ्या पिकाची पाने पिवळी होत आहेत',
    gu: 'મારા પાકના પાંદડા પીળા થઈ રહ્યા છે',
    pa: 'ਮੇਰੀ ਫਸਲ ਦੇ ਪੱਤੇ ਪੀਲੇ ਹੋ ਰਹੇ ਹਨ',
    bn: 'আমার ফসলের পাতা হলুদ হয়ে যাচ্ছে'
  }
  return messages[language as keyof typeof messages] || messages.en
}

export default function KrishiGPT() {
  const [selectedLanguage, setSelectedLanguage] = useState('hi')
  const [isRecording, setIsRecording] = useState(false)
  const [uploadedImage, setUploadedImage] = useState<string | null>(null)
  const [analysisResult, setAnalysisResult] = useState<any>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [chatMessages, setChatMessages] = useState<Array<{type: 'user' | 'bot', message: string, timestamp: Date}>>([])
  const [currentMessage, setCurrentMessage] = useState('')
  const [selectedScheme, setSelectedScheme] = useState<any>(null)
  const [activeTab, setActiveTab] = useState('chat')
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleVoiceInput = () => {
    setIsRecording(!isRecording)
    if (!isRecording) {
      setTimeout(() => {
        setIsRecording(false)
        const voiceMessage = getVoiceMessage(selectedLanguage)
        setChatMessages(prev => [...prev, {
          type: 'user',
          message: voiceMessage,
          timestamp: new Date()
        }])
        
        setTimeout(() => {
          const response = getAIResponse(voiceMessage, selectedLanguage)
          setChatMessages(prev => [...prev, {
            type: 'bot',
            message: response,
            timestamp: new Date()
          }])
        }, 1500)
      }, 3000)
    }
  }

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        setUploadedImage(e.target?.result as string)
        setIsAnalyzing(true)
        
        setTimeout(() => {
          setAnalysisResult({
            disease: 'Leaf Blight',
            confidence: 87,
            severity: 'Moderate',
            treatment: 'Apply copper-based fungicide',
            fertilizer: 'NPK 19:19:19',
            prevention: 'Ensure proper drainage and air circulation'
          })
          setIsAnalyzing(false)
        }, 3000)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSendMessage = () => {
    if (currentMessage.trim()) {
      setChatMessages(prev => [...prev, {
        type: 'user',
        message: currentMessage,
        timestamp: new Date()
      }])
      
      setTimeout(() => {
        const response = getAIResponse(currentMessage, selectedLanguage)
        setChatMessages(prev => [...prev, {
          type: 'bot',
          message: response,
          timestamp: new Date()
        }])
      }, 1000)
      
      setCurrentMessage('')
    }
  }

  const handleQuickAction = (action: string) => {
    const actionMessages = {
      pest: {
        hi: 'कीट पहचान के लिए कृपया अपनी फसल की तस्वीर अपलोड करें।',
        en: 'Please upload a photo of your crop for pest identification.',
        kn: 'ಕೀಟ ಗುರುತಿಸಲು ದಯವಿಟ್ಟು ನಿಮ್ಮ ಬೆಳೆಯ ಫೋಟೋವನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಿ.'
      },
      disease: {
        hi: 'फसल रोग की जांच के लिए पत्तियों की स्पष्ट तस्वीर भेजें।',
        en: 'Send a clear photo of leaves for crop disease analysis.',
        kn: 'ಬೆಳೆ ರೋಗ ವಿಶ್ಲೇಷಣೆಗಾಗಿ ಎಲೆಗಳ ಸ್ಪಷ್ಟ ಫೋಟೋವನ್ನು ಕಳುಹಿಸಿ.'
      },
      weather: {
        hi: 'मौसम अलर्ट सक्रिय है। आज बारिश की 20% संभावना है।',
        en: 'Weather alert active. 20% chance of rain today.',
        kn: 'ಹವಾಮಾನ ಎಚ್ಚರಿಕೆ ಸಕ್ರಿಯವಾಗಿದೆ. ಇಂದು 20% ಮಳೆಯ ಸಾಧ್ಯತೆ.'
      },
      schemes: {
        hi: 'सरकारी योजनाओं की जानकारी के लिए योजना टैब देखें।',
        en: 'Check the schemes tab for government program information.',
        kn: 'ಸರ್ಕಾರಿ ಯೋಜನೆಗಳ ಮಾಹಿತಿಗಾಗಿ ಯೋಜನೆಗಳ ಟ್ಯಾಬ್ ನೋಡಿ.'
      },
      expert: {
        hi: 'विशेषज्ञ से बात करने के लिए कॉल बैक का अनुरोध भेजा गया।',
        en: 'Callback request sent to connect with agricultural expert.',
        kn: 'ಕೃಷಿ ತಜ್ಞರೊಂದಿಗೆ ಸಂಪರ್ಕಿಸಲು ಕಾಲ್‌ಬ್ಯಾಕ್ ವಿನಂತಿ ಕಳುಹಿಸಲಾಗಿದೆ.'
      }
    }

    const message = actionMessages[action as keyof typeof actionMessages]?.[selectedLanguage as keyof typeof actionMessages.pest] || 
                   actionMessages[action as keyof typeof actionMessages]?.en || 
                   'Action processed successfully.'

    setChatMessages(prev => [...prev, {
      type: 'bot',
      message: message,
      timestamp: new Date()
    }])

    // Navigate to relevant tab for some actions
    if (action === 'pest' || action === 'disease') {
      setActiveTab('analysis')
    } else if (action === 'weather') {
      setActiveTab('weather')
    } else if (action === 'schemes') {
      setActiveTab('schemes')
    }
  }

  const handleSchemeAction = (scheme: any, actionType: 'learn' | 'apply') => {
    if (actionType === 'learn') {
      setSelectedScheme(scheme)
    } else if (actionType === 'apply') {
      if (scheme.applyUrl && scheme.applyUrl !== '#') {
        window.open(scheme.applyUrl, '_blank')
      } else {
        alert('Application portal will be available soon!')
      }
    }
  }

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Enhanced Animated Background */}
      <div className="fixed inset-0 gradient-mesh opacity-30"></div>
      <div className="fixed inset-0 bg-gradient-to-br from-emerald-50/80 via-blue-50/60 to-purple-50/80"></div>
      
      {/* Floating Particles */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className={`absolute w-2 h-2 bg-gradient-to-r from-emerald-400 to-blue-400 rounded-full particle opacity-60`}
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 6}s`,
              animationDuration: `${4 + Math.random() * 4}s`
            }}
          />
        ))}
      </div>

      {/* Enhanced Header */}
      <header className="relative glass-card shadow-2xl border-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-24">
            <div className="flex items-center space-x-6">
              <div className="relative animate-float-gentle">
                <div className="bg-gradient-to-br from-emerald-400 via-green-500 to-teal-600 p-4 rounded-3xl shadow-2xl animate-glow-pulse">
                  <Bot className="h-10 w-10 text-white" />
                </div>
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full animate-bounce flex items-center justify-center">
                  <Sparkles className="h-3 w-3 text-white" />
                </div>
              </div>
              <div className="animate-fade-in-scale">
                <h1 className="text-4xl font-black bg-gradient-to-r from-emerald-600 via-green-500 to-teal-600 bg-clip-text text-transparent">
                  KrishiGPT
                </h1>
                <p className="text-lg text-gray-700 flex items-center font-bold">
                  <Brain className="h-4 w-4 mr-2 text-purple-500 animate-pulse" />
                  <span className="text-gradient-rainbow">AI-Powered Farming Revolution</span>
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-6">
              <div className="hidden md:flex items-center space-x-3 glass-effect px-4 py-3 rounded-full border border-emerald-200/50">
                <div className="relative">
                  <div className="w-3 h-3 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full animate-pulse"></div>
                  <div className="absolute inset-0 w-3 h-3 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full animate-ping"></div>
                </div>
                <span className="text-sm text-emerald-700 font-bold">AI Online</span>
                <Trophy className="h-4 w-4 text-yellow-500" />
              </div>
              
              <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                <SelectTrigger className="w-48 glass-card border-emerald-200/50 hover:border-emerald-300 transition-all duration-300 hover:shadow-lg">
                  <Languages className="h-5 w-5 mr-2 text-emerald-600" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="glass-card">
                  {languages.map((lang) => (
                    <SelectItem key={lang.code} value={lang.code} className="hover:bg-emerald-50/80">
                      <span className="flex items-center">
                        <span className="mr-3 text-xl">{lang.flag}</span>
                        <span className="font-medium">{lang.name}</span>
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </header>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
          {/* Enhanced Tab Navigation */}
          <div className="flex justify-center">
            <TabsList className="glass-card p-2 rounded-3xl shadow-2xl border-0 bg-gradient-to-r from-white/80 to-white/60">
              <div className="grid grid-cols-5 gap-2">
                {[
                  { value: 'chat', icon: MessageCircle, label: 'AI Chat', gradient: 'from-emerald-500 to-green-500' },
                  { value: 'analysis', icon: Brain, label: 'Analysis', gradient: 'from-blue-500 to-cyan-500' },
                  { value: 'weather', icon: Cloud, label: 'Weather', gradient: 'from-orange-500 to-yellow-500' },
                  { value: 'fertilizer', icon: Leaf, label: 'Fertilizer', gradient: 'from-purple-500 to-pink-500' },
                  { value: 'schemes', icon: Banknote, label: 'Schemes', gradient: 'from-indigo-500 to-purple-500' }
                ].map((tab) => (
                  <TabsTrigger 
                    key={tab.value}
                    value={tab.value} 
                    className={`flex items-center space-x-3 px-6 py-4 rounded-2xl font-bold transition-all duration-300 data-[state=active]:bg-gradient-to-r data-[state=active]:${tab.gradient} data-[state=active]:text-white data-[state=active]:shadow-2xl data-[state=active]:scale-105 hover:scale-102 btn-magical`}
                  >
                    <tab.icon className="h-5 w-5" />
                    <span className="hidden sm:inline text-sm">{tab.label}</span>
                  </TabsTrigger>
                ))}
              </div>
            </TabsList>
          </div>

          {/* Enhanced Chat Tab */}
          <TabsContent value="chat" className="space-y-8 animate-slide-in-up">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <Card className="glass-card border-0 shadow-2xl card-hover-3d overflow-hidden">
                  <CardHeader className="bg-gradient-to-r from-emerald-500 via-green-500 to-teal-500 text-white relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-r from-emerald-600/20 to-teal-600/20 animate-pulse"></div>
                    <CardTitle className="flex items-center space-x-4 relative z-10">
                      <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-lg">
                        <Bot className="h-8 w-8" />
                      </div>
                      <div>
                        <span className="text-2xl font-black">AI Assistant</span>
                        <p className="text-emerald-100 text-base font-medium mt-1">Your intelligent farming companion</p>
                      </div>
                      <div className="ml-auto flex items-center space-x-2">
                        <div className="w-3 h-3 bg-green-300 rounded-full animate-pulse"></div>
                        <span className="text-sm font-bold">Live</span>
                      </div>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-8 space-y-8">
                    {/* Enhanced Chat Messages */}
                    <div className="h-96 overflow-y-auto glass-effect rounded-3xl p-8 space-y-6 border border-emerald-100/50">
                      {chatMessages.length === 0 ? (
                        <div className="text-center py-12 animate-bounce-in">
                          <div className="relative mb-8">
                            <div className="w-24 h-24 mx-auto bg-gradient-to-br from-emerald-400 to-blue-500 rounded-full flex items-center justify-center shadow-2xl animate-glow-pulse">
                              <Bot className="h-12 w-12 text-white" />
                            </div>
                            <div className="absolute -top-2 -right-2 w-8 h-8 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center animate-bounce">
                              <Wand2 className="h-4 w-4 text-white" />
                            </div>
                          </div>
                          <h3 className="text-2xl font-bold mb-4 text-gradient-rainbow">Welcome to KrishiGPT!</h3>
                          <p className="text-gray-600 text-lg mb-6">Your AI-powered farming assistant is ready to help</p>
                          <div className="flex flex-wrap justify-center gap-4">
                            {[
                              { icon: Headphones, label: 'Voice Support', color: 'emerald' },
                              { icon: Globe, label: '9 Languages', color: 'blue' },
                              { icon: Brain, label: 'AI Powered', color: 'purple' },
                              { icon: Target, label: '24/7 Available', color: 'orange' }
                            ].map((feature, i) => (
                              <Badge key={i} className={`bg-${feature.color}-100 text-${feature.color}-700 px-4 py-2 text-sm font-bold animate-fade-in-scale`} style={{ animationDelay: `${i * 0.1}s` }}>
                                <feature.icon className="h-4 w-4 mr-2" />
                                {feature.label}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      ) : (
                        chatMessages.map((msg, index) => (
                          <div key={index} className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'} animate-slide-in-up`} style={{ animationDelay: `${index * 0.1}s` }}>
                            <div className={`max-w-sm lg:max-w-md px-6 py-4 rounded-3xl shadow-xl card-hover-3d ${
                              msg.type === 'user' 
                                ? 'bg-gradient-to-r from-emerald-500 to-green-500 text-white' 
                                : 'glass-card border border-emerald-100/50'
                            }`}>
                              <div className="flex items-start space-x-3">
                                <div className={`p-2 rounded-full ${msg.type === 'user' ? 'bg-white/20' : 'bg-gradient-to-r from-emerald-400 to-blue-500'}`}>
                                  {msg.type === 'user' ? 
                                    <Fingerprint className="h-4 w-4 text-white" /> : 
                                    <Bot className="h-4 w-4 text-white" />
                                  }
                                </div>
                                <div className="flex-1">
                                  <p className="text-sm leading-relaxed font-medium">{msg.message}</p>
                                  <p className={`text-xs mt-2 flex items-center ${
                                    msg.type === 'user' ? 'text-emerald-100' : 'text-gray-500'
                                  }`}>
                                    <Clock className="h-3 w-3 mr-1" />
                                    {msg.timestamp.toLocaleTimeString()}
                                  </p>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))
                      )}
                    </div>

                    {/* Enhanced Voice Input */}
                    <div className="flex items-center space-x-4">
                      <Button
                        onClick={handleVoiceInput}
                        className={`flex-1 h-16 text-lg font-bold rounded-3xl shadow-2xl transition-all duration-500 transform hover:scale-105 btn-magical ${
                          isRecording 
                            ? 'bg-gradient-to-r from-red-500 via-pink-500 to-purple-500 hover:from-red-600 hover:via-pink-600 hover:to-purple-600 animate-pulse neon-glow' 
                            : 'bg-gradient-to-r from-emerald-500 via-green-500 to-teal-500 hover:from-emerald-600 hover:via-green-600 hover:to-teal-600 animate-glow-pulse'
                        }`}
                      >
                        {isRecording ? (
                          <div className="flex items-center space-x-4">
                            <div className="relative">
                              <MicOff className="h-8 w-8" />
                              <div className="absolute -inset-2 bg-white/30 rounded-full animate-ping"></div>
                            </div>
                            <div className="flex flex-col items-start">
                              <span className="text-lg">Recording...</span>
                              <span className="text-sm opacity-80">Tap to stop</span>
                            </div>
                          </div>
                        ) : (
                          <div className="flex items-center space-x-4">
                            <Mic className="h-8 w-8" />
                            <div className="flex flex-col items-start">
                              <span className="text-lg">🎤 Voice Input</span>
                              <span className="text-sm opacity-80">Speak your question</span>
                            </div>
                          </div>
                        )}
                      </Button>
                    </div>

                    {/* Enhanced Text Input */}
                    <div className="flex space-x-4">
                      <Input
                        placeholder="Type your farming question here..."
                        value={currentMessage}
                        onChange={(e) => setCurrentMessage(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                        className="flex-1 h-14 rounded-2xl border-2 border-emerald-200/50 focus:border-emerald-400 glass-card text-lg font-medium focus-ring"
                      />
                      <Button 
                        onClick={handleSendMessage}
                        className="h-14 px-8 bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 rounded-2xl shadow-2xl transform hover:scale-105 transition-all duration-300 btn-magical"
                      >
                        <span className="hidden sm:inline mr-2 font-bold">Send</span>
                        <Rocket className="h-5 w-5" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Enhanced Quick Actions */}
              <div className="space-y-8">
                <Card className="glass-card border-0 shadow-2xl card-hover-3d">
                  <CardHeader className="bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 text-white">
                    <CardTitle className="text-xl flex items-center">
                      <div className="p-2 bg-white/20 rounded-xl mr-3">
                        <Rocket className="h-6 w-6" />
                      </div>
                      <span className="font-black">Quick Actions</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6 space-y-4">
                    {[
                      { icon: Bug, label: 'Pest Detective', color: 'from-red-500 to-orange-500', action: 'pest', desc: 'AI-powered pest ID' },
                      { icon: Leaf, label: 'Disease Scanner', color: 'from-green-500 to-emerald-500', action: 'disease', desc: 'Smart crop analysis' },
                      { icon: Cloud, label: 'Weather Oracle', color: 'from-blue-500 to-cyan-500', action: 'weather', desc: 'Live weather insights' },
                      { icon: Banknote, label: 'Scheme Finder', color: 'from-purple-500 to-pink-500', action: 'schemes', desc: 'Government benefits' },
                      { icon: Phone, label: 'Expert Connect', color: 'from-indigo-500 to-purple-500', action: 'expert', desc: 'Professional help' }
                    ].map((action, index) => (
                      <Button 
                        key={index}
                        variant="outline" 
                        onClick={() => handleQuickAction(action.action)}
                        className="w-full justify-start h-16 rounded-2xl border-2 hover:border-transparent hover:shadow-2xl transition-all duration-300 group glass-card btn-magical animate-fade-in-scale"
                        style={{ animationDelay: `${index * 0.1}s` }}
                      >
                        <div className={`p-3 rounded-2xl bg-gradient-to-r ${action.color} mr-4 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                          <action.icon className="h-6 w-6 text-white" />
                        </div>
                        <div className="flex-1 text-left">
                          <p className="font-bold text-gray-800">{action.label}</p>
                          <p className="text-xs text-gray-600">{action.desc}</p>
                        </div>
                        <Sparkles className="h-4 w-4 text-gray-400 group-hover:text-yellow-500 transition-colors" />
                      </Button>
                    ))}
                  </CardContent>
                </Card>

                <Card className="glass-card border-0 shadow-2xl card-hover-3d">
                  <CardHeader className="bg-gradient-to-r from-yellow-500 via-orange-500 to-red-500 text-white">
                    <CardTitle className="text-lg flex items-center">
                      <div className="p-2 bg-white/20 rounded-xl mr-3">
                        <Lightbulb className="h-5 w-5" />
                      </div>
                      <span className="font-black">Smart Insights</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="space-y-6">
                      {[
                        { 
                          icon: AlertTriangle, 
                          title: 'Weather Alert', 
                          desc: 'Heavy rain expected in 48hrs. Prepare drainage systems now!',
                          color: 'from-red-500 to-orange-500',
                          bgColor: 'from-red-50/80 to-orange-50/80',
                          borderColor: 'red-200'
                        },
                        { 
                          icon: Heart, 
                          title: 'Crop Care', 
                          desc: 'Perfect time for fertilizer application. Soil conditions optimal.',
                          color: 'from-green-500 to-emerald-500',
                          bgColor: 'from-green-50/80 to-emerald-50/80',
                          borderColor: 'green-200'
                        },
                        { 
                          icon: TrendingUp, 
                          title: 'Market Trend', 
                          desc: 'Tomato prices up 15% this week. Good time to harvest!',
                          color: 'from-blue-500 to-cyan-500',
                          bgColor: 'from-blue-50/80 to-cyan-50/80',
                          borderColor: 'blue-200'
                        }
                      ].map((insight, index) => (
                        <div key={index} className={`p-5 bg-gradient-to-r ${insight.bgColor} backdrop-blur-lg rounded-2xl border border-${insight.borderColor} hover:shadow-xl transition-all duration-300 animate-fade-in-scale`} style={{ animationDelay: `${index * 0.2}s` }}>
                          <div className="flex items-start space-x-4">
                            <div className={`p-3 bg-gradient-to-r ${insight.color} rounded-2xl shadow-lg`}>
                              <insight.icon className="h-5 w-5 text-white" />
                            </div>
                            <div className="flex-1">
                              <h4 className="font-bold text-gray-800 mb-2">{insight.title}</h4>
                              <p className="text-sm text-gray-700 leading-relaxed">{insight.desc}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Enhanced Image Analysis Tab */}
          <TabsContent value="analysis" className="space-y-8 animate-slide-in-up">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Card className="glass-card border-0 shadow-2xl card-hover-3d">
                <CardHeader className="bg-gradient-to-r from-blue-500 via-cyan-500 to-teal-500 text-white">
                  <CardTitle className="flex items-center space-x-4">
                    <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-lg">
                      <Camera className="h-8 w-8" />
                    </div>
                    <div>
                      <span className="text-2xl font-black">AI Vision</span>
                      <p className="text-blue-100 text-base font-medium mt-1">Advanced crop disease detection</p>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-8 space-y-8">
                  <div className="border-2 border-dashed border-blue-300/50 rounded-3xl p-12 text-center glass-effect hover:bg-gradient-to-br hover:from-blue-50/50 hover:to-cyan-50/50 transition-all duration-500 cursor-pointer group">
                    {uploadedImage ? (
                      <div className="space-y-6 animate-fade-in-scale">
                        <div className="relative">
                          <img src={uploadedImage || "/placeholder.svg"} alt="Uploaded crop" className="max-h-72 mx-auto rounded-3xl shadow-2xl" />
                          <div className="absolute top-4 right-4 bg-gradient-to-r from-green-500 to-emerald-500 text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg">
                            ✓ Uploaded
                          </div>
                          {isAnalyzing && (
                            <div className="absolute inset-0 bg-blue-500/20 rounded-3xl analysis-scanning"></div>
                          )}
                        </div>
                        <Button
                          onClick={() => fileInputRef.current?.click()}
                          variant="outline"
                          className="glass-card border-blue-200 hover:border-blue-400 rounded-2xl hover:shadow-xl transition-all duration-300 btn-magical"
                        >
                          <Upload className="h-5 w-5 mr-2" />
                          Upload Different Image
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-8 animate-bounce-in">
                        <div className="relative">
                          <div className="w-32 h-32 mx-auto bg-gradient-to-br from-blue-400 to-cyan-500 rounded-full flex items-center justify-center shadow-2xl animate-glow-pulse group-hover:scale-110 transition-transform duration-500">
                            <Camera className="h-16 w-16 text-white" />
                          </div>
                          <div className="absolute -top-4 -right-4 w-12 h-12 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center animate-bounce">
                            <Brain className="h-6 w-6 text-white" />
                          </div>
                        </div>
                        <div>
                          <h3 className="text-2xl font-bold text-gray-800 mb-4">Upload Crop Image</h3>
                          <p className="text-gray-600 text-lg mb-6">Take a photo or upload from gallery for instant AI analysis</p>
                          <div className="flex flex-wrap justify-center gap-4 mb-8">
                            {[
                              { icon: Eye, label: 'AI Detection', color: 'blue' },
                              { icon: Shield, label: '99% Accuracy', color: 'green' },
                              { icon: Zap, label: 'Instant Results', color: 'purple' },
                              { icon: Award, label: 'Expert Grade', color: 'orange' }
                            ].map((feature, i) => (
                              <Badge key={i} className={`bg-${feature.color}-100 text-${feature.color}-700 px-4 py-2 text-sm font-bold animate-fade-in-scale shadow-lg`} style={{ animationDelay: `${i * 0.1}s` }}>
                                <feature.icon className="h-4 w-4 mr-2" />
                                {feature.label}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <Button 
                          onClick={() => fileInputRef.current?.click()}
                          className="bg-gradient-to-r from-blue-500 via-cyan-500 to-teal-500 hover:from-blue-600 hover:via-cyan-600 hover:to-teal-600 rounded-2xl shadow-2xl transform hover:scale-105 transition-all duration-300 text-lg font-bold px-8 py-4 btn-magical"
                        >
                          <Upload className="h-6 w-6 mr-3" />
                          Choose Image
                        </Button>
                      </div>
                    )}
                  </div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </CardContent>
              </Card>

              <Card className="glass-card border-0 shadow-2xl card-hover-3d">
                <CardHeader className="bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 text-white">
                  <CardTitle className="flex items-center space-x-4">
                    <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-lg">
                      <Brain className="h-8 w-8" />
                    </div>
                    <div>
                      <span className="text-2xl font-black">Analysis Results</span>
                      <p className="text-purple-100 text-base font-medium mt-1">AI-powered insights & recommendations</p>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-8">
                  {isAnalyzing ? (
                    <div className="space-y-8 animate-fade-in-scale">
                      <div className="text-center">
                        <div className="relative">
                          <div className="w-24 h-24 mx-auto">
                            <div className="absolute inset-0 rounded-full border-4 border-purple-200"></div>
                            <div className="absolute inset-0 rounded-full border-4 border-transparent border-t-purple-600 animate-spin"></div>
                            <div className="absolute inset-0 flex items-center justify-center">
                              <Brain className="h-8 w-8 text-purple-600 animate-pulse" />
                            </div>
                          </div>
                        </div>
                        <h3 className="mt-6 text-2xl font-bold text-gray-700">AI Analyzing...</h3>
                        <p className="text-gray-500 text-lg mt-2">Advanced neural networks examining your crop</p>
                      </div>
                      <Progress value={75} className="w-full h-4 bg-purple-100 rounded-full overflow-hidden">
                        <div className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full animate-pulse"></div>
                      </Progress>
                      <div className="flex justify-center space-x-6">
                        {[
                          { icon: Eye, label: 'Scanning', color: 'purple' },
                          { icon: Brain, label: 'Processing', color: 'blue' },
                          { icon: Lightbulb, label: 'Analyzing', color: 'yellow' }
                        ].map((step, i) => (
                          <Badge key={i} className={`bg-${step.color}-100 text-${step.color}-700 animate-pulse px-4 py-2 font-bold`} style={{ animationDelay: `${i * 0.3}s` }}>
                            <step.icon className="h-4 w-4 mr-2" />
                            {step.label}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ) : analysisResult ? (
                    <div className="space-y-8 animate-slide-in-up">
                      <Alert className="border-red-200 bg-gradient-to-r from-red-50/80 to-orange-50/80 backdrop-blur-lg p-6 rounded-2xl shadow-xl">
                        <div className="flex items-center">
                          <div className="p-3 bg-gradient-to-r from-red-500 to-orange-500 rounded-2xl mr-4 shadow-lg">
                            <AlertTriangle className="h-6 w-6 text-white" />
                          </div>
                          <div>
                            <AlertDescription className="font-bold text-lg text-red-800">
                              Disease Detected: {analysisResult.disease}
                            </AlertDescription>
                            <p className="text-red-600 text-sm mt-1">Immediate attention required</p>
                          </div>
                        </div>
                      </Alert>
                      
                      <div className="grid grid-cols-2 gap-6">
                        {[
                          { title: 'Confidence', value: `${analysisResult.confidence}%`, icon: Award, color: 'red', bgColor: 'from-red-50/80 to-orange-50/80' },
                          { title: 'Severity', value: analysisResult.severity, icon: AlertTriangle, color: 'orange', bgColor: 'from-orange-50/80 to-yellow-50/80' }
                        ].map((stat, index) => (
                          <div key={index} className={`p-6 bg-gradient-to-br ${stat.bgColor} backdrop-blur-lg rounded-2xl border border-${stat.color}-200 shadow-xl hover:shadow-2xl transition-shadow duration-300`}>
                            <div className="flex items-center mb-4">
                              <div className={`p-2 bg-gradient-to-r from-${stat.color}-500 to-${stat.color}-600 rounded-xl mr-3`}>
                                <stat.icon className="h-5 w-5 text-white" />
                              </div>
                              <p className={`text-sm font-bold text-${stat.color}-800`}>{stat.title}</p>
                            </div>
                            <p className={`text-3xl font-black text-${stat.color}-600`}>{stat.value}</p>
                          </div>
                        ))}
                      </div>

                      <div className="space-y-6">
                        {[
                          { title: 'Treatment', content: analysisResult.treatment, color: 'green', icon: Shield },
                          { title: 'Recommended Fertilizer', content: analysisResult.fertilizer, color: 'blue', icon: Leaf },
                          { title: 'Prevention Tips', content: analysisResult.prevention, color: 'purple', icon: Heart }
                        ].map((item, index) => (
                          <div key={index} className={`p-6 rounded-2xl bg-gradient-to-r from-${item.color}-50/80 to-${item.color}-100/80 backdrop-blur-lg border border-${item.color}-200 shadow-xl hover:shadow-2xl transition-all duration-300 animate-fade-in-scale`} style={{ animationDelay: `${index * 0.1}s` }}>
                            <div className="flex items-center mb-4">
                              <div className={`p-3 bg-gradient-to-r from-${item.color}-500 to-${item.color}-600 rounded-2xl mr-4 shadow-lg`}>
                                <item.icon className="h-6 w-6 text-white" />
                              </div>
                              <h4 className={`font-black text-xl text-${item.color}-800`}>{item.title}</h4>
                            </div>
                            <p className="text-gray-700 text-base leading-relaxed">{item.content}</p>
                          </div>
                        ))}
                      </div>

                      <Button 
                        onClick={() => setActiveTab('fertilizer')}
                        className="w-full h-16 bg-gradient-to-r from-green-500 via-emerald-500 to-teal-500 hover:from-green-600 hover:via-emerald-600 hover:to-teal-600 rounded-2xl shadow-2xl transform hover:scale-105 transition-all duration-300 text-lg font-bold btn-magical"
                      >
                        <Store className="h-6 w-6 mr-3" />
                        Find Nearby Fertilizer Shops
                        <Sparkles className="h-5 w-5 ml-3" />
                      </Button>
                    </div>
                  ) : (
                    <div className="text-center py-20 animate-bounce-in">
                      <div className="relative mb-8">
                        <div className="w-32 h-32 mx-auto bg-gradient-to-br from-gray-200 to-gray-300 rounded-full flex items-center justify-center shadow-2xl">
                          <Brain className="h-16 w-16 text-gray-400" />
                        </div>
                        <div className="absolute -top-4 -right-4 w-12 h-12 bg-gradient-to-r from-purple-400 to-pink-500 rounded-full flex items-center justify-center animate-bounce">
                          <Wand2 className="h-6 w-6 text-white" />
                        </div>
                      </div>
                      <h3 className="text-2xl font-bold mb-4 text-gray-700">Upload an image to see magic happen</h3>
                      <p className="text-gray-500 text-lg">Get instant AI-powered crop insights and recommendations</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Continue with other tabs - Weather, Fertilizer, Schemes with similar enhanced styling... */}
          
          {/* Enhanced Weather Tab */}
          <TabsContent value="weather" className="space-y-8 animate-slide-in-up">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <Card className="glass-card border-0 shadow-2xl card-hover-3d">
                <CardHeader className="bg-gradient-to-r from-blue-500 via-cyan-500 to-teal-500 text-white">
                  <CardTitle className="flex items-center space-x-4">
                    <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-lg">
                      <Cloud className="h-8 w-8" />
                    </div>
                    <div>
                      <span className="text-2xl font-black">Live Weather</span>
                      <p className="text-blue-100 text-base font-medium mt-1">Real-time conditions</p>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-8 space-y-8">
                  <div className="text-center animate-bounce-in">
                    <div className="relative mb-6">
                      <div className="text-6xl font-black text-blue-600 mb-4">{weatherData.temperature}°C</div>
                      <div className="absolute -top-4 -right-4 w-8 h-8 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full animate-pulse flex items-center justify-center">
                        <Sun className="h-4 w-4 text-white" />
                      </div>
                    </div>
                    <p className="text-gray-600 font-bold text-xl mb-4">{weatherData.condition}</p>
                    <Badge className="bg-blue-100 text-blue-700 px-4 py-2 text-sm font-bold shadow-lg">
                      <MapPin className="h-4 w-4 mr-2" />
                      Your Location
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-6">
                    {[
                      { icon: Droplets, label: 'Humidity', value: `${weatherData.humidity}%`, color: 'blue' },
                      { icon: Wind, label: 'Wind Speed', value: `${weatherData.windSpeed} km/h`, color: 'gray' },
                      { icon: CloudRain, label: 'Rainfall', value: `${weatherData.rainfall} mm`, color: 'indigo' },
                      { icon: Thermometer, label: 'Feels Like', value: '32°C', color: 'red' }
                    ].map((item, index) => (
                      <div key={index} className={`flex items-center space-x-4 p-4 bg-gradient-to-r from-${item.color}-50/80 to-${item.color}-100/80 backdrop-blur-lg rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 animate-fade-in-scale`} style={{ animationDelay: `${index * 0.1}s` }}>
                        <div className={`p-3 bg-gradient-to-r from-${item.color}-500 to-${item.color}-600 rounded-2xl shadow-lg`}>
                          <item.icon className="h-6 w-6 text-white" />
                        </div>
                        <div>
                          <p className="text-xs text-gray-500 font-bold uppercase tracking-wider">{item.label}</p>
                          <p className="font-black text-lg text-gray-800">{item.value}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Continue with other weather components and remaining tabs... */}
            </div>
          </TabsContent>

          {/* Enhanced Fertilizer Tab */}
          <TabsContent value="fertilizer" className="space-y-8 animate-slide-in-up">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Card className="glass-card border-0 shadow-2xl card-hover-3d">
                <CardHeader className="bg-gradient-to-r from-green-500 via-emerald-500 to-teal-500 text-white">
                  <CardTitle className="flex items-center space-x-4">
                    <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-lg">
                      <Leaf className="h-8 w-8" />
                    </div>
                    <div>
                      <span className="text-2xl font-black">Smart Fertilizer</span>
                      <p className="text-green-100 text-base font-medium mt-1">AI-powered recommendations</p>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-8 space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {[
                      {
                        name: 'NPK 19:19:19',
                        description: 'Balanced nutrition for all crops',
                        dosage: '25kg/acre',
                        price: '₹1,200/bag',
                        suitability: 95,
                        benefits: ['Balanced growth', 'Higher yield', 'Disease resistance'],
                        color: 'green'
                      },
                      {
                        name: 'Urea',
                        description: 'High nitrogen for leafy growth',
                        dosage: '50kg/acre',
                        price: '₹300/bag',
                        suitability: 88,
                        benefits: ['Rapid growth', 'Green foliage', 'Cost effective'],
                        color: 'blue'
                      },
                      {
                        name: 'DAP',
                        description: 'Phosphorus for root development',
                        dosage: '30kg/acre',
                        price: '₹1,350/bag',
                        suitability: 92,
                        benefits: ['Strong roots', 'Better flowering', 'Improved quality'],
                        color: 'purple'
                      },
                      {
                        name: 'Potash',
                        description: 'Potassium for fruit quality',
                        dosage: '20kg/acre',
                        price: '₹800/bag',
                        suitability: 85,
                        benefits: ['Better fruits', 'Disease tolerance', 'Water efficiency'],
                        color: 'orange'
                      }
                    ].map((fertilizer, index) => (
                      <div key={index} className={`p-6 border rounded-2xl bg-gradient-to-br from-${fertilizer.color}-50/80 to-${fertilizer.color}-100/80 backdrop-blur-lg border-${fertilizer.color}-200 hover:shadow-xl transition-all duration-300 animate-fade-in-scale`} style={{ animationDelay: `${index * 0.1}s` }}>
                        <div className="flex items-center mb-4">
                          <div className={`p-3 bg-gradient-to-r from-${fertilizer.color}-500 to-${fertilizer.color}-600 rounded-2xl mr-4 shadow-lg`}>
                            <Leaf className="h-6 w-6 text-white" />
                          </div>
                          <div className="flex-1">
                            <h4 className={`font-black text-xl text-${fertilizer.color}-800`}>{fertilizer.name}</h4>
                            <p className="text-sm text-gray-600">{fertilizer.description}</p>
                          </div>
                          <Badge className={`bg-${fertilizer.color}-100 text-${fertilizer.color}-700 font-bold`}>
                            {fertilizer.suitability}% Match
                          </Badge>
                        </div>
                        
                        <div className="space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <div className="p-3 bg-white/80 backdrop-blur-sm rounded-xl">
                              <p className="text-xs font-bold text-gray-600 uppercase">Dosage</p>
                              <p className={`text-lg font-black text-${fertilizer.color}-600`}>{fertilizer.dosage}</p>
                            </div>
                            <div className="p-3 bg-white/80 backdrop-blur-sm rounded-xl">
                              <p className="text-xs font-bold text-gray-600 uppercase">Price</p>
                              <p className={`text-lg font-black text-${fertilizer.color}-600`}>{fertilizer.price}</p>
                            </div>
                          </div>
                          
                          <div className="space-y-2">
                            <p className="text-sm font-bold text-gray-700">Key Benefits:</p>
                            <div className="flex flex-wrap gap-2">
                              {fertilizer.benefits.map((benefit, i) => (
                                <Badge key={i} variant="secondary" className="text-xs">
                                  {benefit}
                                </Badge>
                              ))}
                            </div>
                          </div>
                          
                          <Button 
                            onClick={() => {
                              setChatMessages(prev => [...prev, {
                                type: 'bot',
                                message: `Showing nearby shops for ${fertilizer.name}...`,
                                timestamp: new Date()
                              }])
                            }}
                            className={`w-full bg-gradient-to-r from-${fertilizer.color}-500 to-${fertilizer.color}-600 hover:from-${fertilizer.color}-600 hover:to-${fertilizer.color}-700 rounded-xl shadow-lg transform hover:scale-105 transition-all duration-200 btn-magical`}
                          >
                            <Store className="h-4 w-4 mr-2" />
                            Find Shops
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="p-6 bg-gradient-to-r from-yellow-50/80 to-orange-50/80 backdrop-blur-lg rounded-2xl border border-yellow-200 shadow-xl">
                    <div className="flex items-center mb-4">
                      <div className="p-3 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-2xl mr-4 shadow-lg">
                        <Lightbulb className="h-6 w-6 text-white" />
                      </div>
                      <h4 className="font-black text-xl text-yellow-800">Application Tips</h4>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {[
                        'Apply fertilizer in early morning or evening',
                        'Water the field immediately after application',
                        'Mix with soil for better nutrient absorption',
                        'Follow recommended dosage to avoid crop burning',
                        'Store fertilizers in dry, cool places',
                        'Use protective equipment during application'
                      ].map((tip, index) => (
                        <div key={index} className="flex items-center space-x-3">
                          <div className="w-2 h-2 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full"></div>
                          <p className="text-sm text-gray-700 font-medium">{tip}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-card border-0 shadow-2xl card-hover-3d">
                <CardHeader className="bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 text-white">
                  <CardTitle className="flex items-center space-x-4">
                    <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-lg">
                      <MapPin className="h-8 w-8" />
                    </div>
                    <div>
                      <span className="text-2xl font-black">Nearby Shops</span>
                      <p className="text-purple-100 text-base font-medium mt-1">Location-based results</p>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-8">
                  <div className="space-y-6">
                    {fertilizerShops.map((shop, index) => (
                      <div key={index} className="p-6 border rounded-2xl hover:bg-gradient-to-r hover:from-purple-50/80 hover:to-pink-50/80 backdrop-blur-lg transition-all duration-300 hover:shadow-xl border-purple-100 animate-fade-in-scale" style={{ animationDelay: `${index * 0.1}s` }}>
                        <div className="flex justify-between items-start mb-4">
                          <div className="flex items-center space-x-4">
                            <div className="p-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl shadow-lg">
                              <Store className="h-6 w-6 text-white" />
                            </div>
                            <div>
                              <h4 className="font-black text-lg text-gray-800">{shop.name}</h4>
                              <div className="flex items-center space-x-4 text-sm text-gray-600 mt-1">
                                <div className="flex items-center space-x-1">
                                  <Navigation className="h-4 w-4 text-purple-500" />
                                  <span className="font-medium">{shop.distance}</span>
                                </div>
                                <div className="flex items-center space-x-1">
                                  <Phone className="h-4 w-4 text-green-500" />
                                  <span className="font-medium">{shop.phone}</span>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge className="bg-yellow-100 text-yellow-800 flex items-center font-bold">
                              <Star className="h-3 w-3 mr-1" />
                              {shop.rating}
                            </Badge>
                            <Badge className="bg-green-100 text-green-800 font-bold">
                              Open
                            </Badge>
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-3 gap-4 mb-4">
                          {['NPK Available', 'Urea Stock: 50+', 'DAP Available'].map((stock, i) => (
                            <div key={i} className="p-2 bg-green-50/80 backdrop-blur-sm rounded-lg text-center">
                              <p className="text-xs font-bold text-green-700">{stock}</p>
                            </div>
                          ))}
                        </div>
                        
                        <div className="flex space-x-3">
                          <Button 
                            size="sm" 
                            variant="outline" 
                            onClick={() => {
                              setChatMessages(prev => [...prev, {
                                type: 'bot',
                                message: `Opening directions to ${shop.name}...`,
                                timestamp: new Date()
                              }])
                            }}
                            className="flex-1 border-purple-200 hover:border-purple-400 rounded-xl hover:shadow-md transition-all duration-200 btn-magical"
                          >
                            <Navigation className="h-4 w-4 mr-2" />
                            Directions
                          </Button>
                          <Button 
                            size="sm" 
                            onClick={() => {
                              window.open(`tel:${shop.phone}`, '_self')
                            }}
                            className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 rounded-xl shadow-lg transform hover:scale-105 transition-all duration-200 btn-magical"
                          >
                            <Phone className="h-4 w-4 mr-2" />
                            Call Now
                          </Button>
                          <Button 
                            size="sm" 
                            onClick={() => {
                              setChatMessages(prev => [...prev, {
                                type: 'bot',
                                message: `Checking current stock at ${shop.name}...`,
                                timestamp: new Date()
                              }])
                            }}
                            className="flex-1 bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 rounded-xl shadow-lg transform hover:scale-105 transition-all duration-200 btn-magical"
                          >
                            <Eye className="h-4 w-4 mr-2" />
                            Check Stock
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Enhanced Government Schemes Tab */}
          <TabsContent value="schemes" className="space-y-8 animate-slide-in-up">
            {/* Filter Tabs */}
            <div className="flex justify-center">
              <div className="glass-card p-1 rounded-2xl shadow-lg border border-indigo-100">
                <div className="flex space-x-1">
                  <Button
                    variant="ghost"
                    className="rounded-xl px-6 py-2 bg-gradient-to-r from-indigo-500 to-purple-500 text-white font-bold"
                  >
                    All Schemes
                  </Button>
                  <Button
                    variant="ghost"
                    className="rounded-xl px-6 py-2 hover:bg-green-50 font-bold"
                  >
                    Current
                  </Button>
                  <Button
                    variant="ghost"
                    className="rounded-xl px-6 py-2 hover:bg-blue-50 font-bold"
                  >
                    Upcoming
                  </Button>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {governmentSchemes.map((scheme, index) => (
                <Card key={scheme.id} className="glass-card border-0 shadow-2xl hover:shadow-3xl transition-all duration-300 card-hover-3d animate-fade-in-scale" style={{ animationDelay: `${index * 0.1}s` }}>
                  <CardHeader className={`bg-gradient-to-r ${
                    scheme.type === 'current' 
                      ? 'from-indigo-500 via-purple-500 to-pink-500' 
                      : 'from-blue-500 via-cyan-500 to-teal-500'
                  } text-white rounded-t-lg`}>
                    <div className="flex justify-between items-start">
                      <div className="flex items-center space-x-4">
                        <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-lg">
                          {scheme.type === 'current' ? (
                            <Banknote className="h-8 w-8" />
                          ) : (
                            <Rocket className="h-8 w-8" />
                          )}
                        </div>
                        <div>
                          <CardTitle className="text-xl font-black">{scheme.name}</CardTitle>
                          <Badge className={`mt-2 ${
                            scheme.type === 'current' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'
                          } font-bold`}>
                            {scheme.type === 'current' ? '🟢 Active Now' : '🔵 Coming Soon'}
                          </Badge>
                        </div>
                      </div>
                      <Badge variant={scheme.status === 'Active' ? 'default' : 'secondary'} className={`${
                        scheme.status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      } font-bold px-3 py-1`}>
                        {scheme.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="p-8 space-y-6">
                    <p className="text-gray-700 leading-relaxed font-medium">{scheme.description}</p>
                    
                    <div className="grid grid-cols-2 gap-6">
                      <div className="p-4 bg-gradient-to-br from-green-50/80 to-emerald-50/80 backdrop-blur-lg rounded-2xl border border-green-200 shadow-lg">
                        <div className="flex items-center mb-3">
                          <div className="p-2 bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl mr-3">
                            <Banknote className="h-5 w-5 text-white" />
                          </div>
                          <p className="text-sm font-black text-green-800 uppercase">Benefit Amount</p>
                        </div>
                        <p className="text-2xl font-black text-green-600">{scheme.amount}</p>
                      </div>
                      <div className="p-4 bg-gradient-to-br from-red-50/80 to-orange-50/80 backdrop-blur-lg rounded-2xl border border-red-200 shadow-lg">
                        <div className="flex items-center mb-3">
                          <div className="p-2 bg-gradient-to-r from-red-500 to-orange-500 rounded-xl mr-3">
                            <Calendar className="h-5 w-5 text-white" />
                          </div>
                          <p className="text-sm font-black text-red-800 uppercase">Deadline</p>
                        </div>
                        <p className="text-lg font-black text-red-600">{scheme.deadline}</p>
                      </div>
                    </div>

                    <div className="p-4 bg-gradient-to-r from-blue-50/80 to-cyan-50/80 backdrop-blur-lg rounded-2xl border border-blue-200 shadow-lg">
                      <div className="flex items-center mb-3">
                        <div className="p-2 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-xl mr-3">
                          <Users className="h-5 w-5 text-white" />
                        </div>
                        <p className="text-sm font-black text-blue-800 uppercase">Eligibility</p>
                      </div>
                      <p className="text-sm text-gray-700 font-medium">{scheme.eligibility}</p>
                    </div>

                    {/* Benefits List */}
                    <div className="p-4 bg-gradient-to-r from-purple-50/80 to-pink-50/80 backdrop-blur-lg rounded-2xl border border-purple-200 shadow-lg">
                      <div className="flex items-center mb-4">
                        <div className="p-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl mr-3">
                          <Star className="h-5 w-5 text-white" />
                        </div>
                        <p className="text-sm font-black text-purple-800 uppercase">Key Benefits</p>
                      </div>
                      <ul className="text-sm text-gray-700 space-y-2">
                        {scheme.benefits.map((benefit, idx) => (
                          <li key={idx} className="flex items-center font-medium">
                            <div className="w-2 h-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full mr-3"></div>
                            {benefit}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="flex space-x-4">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button 
                            onClick={() => setSelectedScheme(scheme)}
                            className="flex-1 bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 rounded-xl shadow-lg transform hover:scale-105 transition-all duration-200 font-bold btn-magical"
                          >
                            <BookOpen className="h-4 w-4 mr-2" />
                            Learn More
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-2xl glass-card">
                          <DialogHeader>
                            <DialogTitle className="text-2xl font-black text-gray-800">
                              {selectedScheme?.name}
                            </DialogTitle>
                            <DialogDescription className="text-gray-600 font-medium">
                              Complete details and application process
                            </DialogDescription>
                          </DialogHeader>
                          {selectedScheme && (
                            <div className="space-y-6 max-h-96 overflow-y-auto">
                              <div>
                                <h4 className="font-black text-gray-800 mb-3">Description</h4>
                                <p className="text-gray-700 font-medium">{selectedScheme.description}</p>
                              </div>
                              
                              <div>
                                <h4 className="font-black text-gray-800 mb-3">Required Documents</h4>
                                <ul className="text-sm text-gray-700 space-y-2">
                                  {selectedScheme.documents.map((doc: string, idx: number) => (
                                    <li key={idx} className="flex items-center font-medium">
                                      <FileText className="h-4 w-4 mr-3 text-blue-500" />
                                      {doc}
                                    </li>
                                  ))}
                                </ul>
                              </div>

                              <div>
                                <h4 className="font-black text-gray-800 mb-3">Application Process</h4>
                                <ol className="text-sm text-gray-700 space-y-3">
                                  {[
                                    'Gather all required documents',
                                    'Visit the official portal or nearest center',
                                    'Fill the application form completely',
                                    'Submit and track your application status'
                                  ].map((step, idx) => (
                                    <li key={idx} className="flex items-start font-medium">
                                      <span className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs mr-3 mt-0.5 font-bold">{idx + 1}</span>
                                      {step}
                                    </li>
                                  ))}
                                </ol>
                              </div>
                            </div>
                          )}
                        </DialogContent>
                      </Dialog>
                      
                      <Button 
                        onClick={() => handleSchemeAction(scheme, 'apply')}
                        className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 rounded-xl shadow-lg transform hover:scale-105 transition-all duration-200 font-bold btn-magical"
                      >
                        {scheme.applyUrl === '#' ? (
                          <>
                            <Clock className="h-4 w-4 mr-2" />
                            Coming Soon
                          </>
                        ) : (
                          <>
                            <ExternalLink className="h-4 w-4 mr-2" />
                            Apply Now
                          </>
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Enhanced Application Status */}
            <Card className="glass-card border-0 shadow-2xl card-hover-3d">
              <CardHeader className="bg-gradient-to-r from-green-500 via-emerald-500 to-teal-500 text-white rounded-t-lg">
                <CardTitle className="flex items-center space-x-4">
                  <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-lg">
                    <CheckCircle className="h-8 w-8" />
                  </div>
                  <div>
                    <span className="text-2xl font-black">Your Applications</span>
                    <p className="text-green-100 text-base font-medium mt-1">Track your scheme applications</p>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-8">
                <div className="space-y-6">
                  {[
                    {
                      scheme: 'PM-KISAN Application',
                      appliedDate: '15 Nov 2024',
                      status: 'Approved',
                      statusColor: 'green',
                      nextAction: 'Next payment: Dec 2024',
                      progress: 100
                    },
                    {
                      scheme: 'Crop Insurance',
                      appliedDate: '20 Nov 2024',
                      status: 'Under Review',
                      statusColor: 'yellow',
                      nextAction: 'Processing time: 7-10 days',
                      progress: 60
                    },
                    {
                      scheme: 'Kisan Credit Card',
                      appliedDate: '25 Nov 2024',
                      status: 'Documents Pending',
                      statusColor: 'red',
                      nextAction: 'Submit land records',
                      progress: 30
                    }
                  ].map((application, index) => (
                    <div key={index} className={`flex items-center justify-between p-6 border rounded-2xl bg-gradient-to-r from-${application.statusColor}-50/80 to-${application.statusColor}-100/80 backdrop-blur-lg border-${application.statusColor}-200 hover:shadow-xl transition-all duration-300 animate-fade-in-scale`} style={{ animationDelay: `${index * 0.1}s` }}>
                      <div className="flex items-center space-x-6">
                        <div className={`p-4 bg-gradient-to-r from-${application.statusColor}-500 to-${application.statusColor}-600 rounded-2xl shadow-lg`}>
                          {application.status === 'Approved' ? (
                            <CheckCircle className="h-8 w-8 text-white" />
                          ) : application.status === 'Under Review' ? (
                            <Clock className="h-8 w-8 text-white" />
                          ) : (
                            <AlertTriangle className="h-8 w-8 text-white" />
                          )}
                        </div>
                        <div>
                          <p className="font-black text-lg text-gray-800">{application.scheme}</p>
                          <p className="text-sm text-gray-600 font-medium">Applied on: {application.appliedDate}</p>
                          <p className={`text-xs text-${application.statusColor}-600 font-bold mt-1`}>{application.nextAction}</p>
                          <div className="mt-2 w-48">
                            <Progress value={application.progress} className={`h-2 bg-${application.statusColor}-100`} />
                          </div>
                        </div>
                      </div>
                      <div className="text-right space-y-3">
                        <Badge className={`bg-${application.statusColor}-100 text-${application.statusColor}-800 px-4 py-2 text-sm font-bold`}>
                          {application.status === 'Approved' ? '✓ Approved' : 
                           application.status === 'Under Review' ? '⏳ Under Review' : 
                           '⚠️ Action Required'}
                        </Badge>
                        <div className="flex space-x-2">
                          <Button size="sm" variant="outline" className="font-bold">
                            <Eye className="h-3 w-3 mr-1" />
                            Track
                          </Button>
                          {application.status === 'Approved' && (
                            <Button size="sm" variant="outline" className="font-bold">
                              <Download className="h-3 w-3 mr-1" />
                              Certificate
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

        </Tabs>
      </div>

      {/* Enhanced Floating Action Button */}
      <div className="fixed bottom-8 right-8 z-50">
        <Button 
          className="w-20 h-20 rounded-full bg-gradient-to-r from-emerald-500 via-green-500 to-teal-500 hover:from-emerald-600 hover:via-green-600 hover:to-teal-600 shadow-2xl transform hover:scale-110 transition-all duration-300 animate-glow-pulse btn-magical"
          onClick={handleVoiceInput}
        >
          {isRecording ? (
            <div className="relative">
              <MicOff className="h-10 w-10 text-white animate-pulse" />
              <div className="absolute -inset-2 bg-white/30 rounded-full animate-ping"></div>
            </div>
          ) : (
            <Mic className="h-10 w-10 text-white" />
          )}
        </Button>
      </div>
    </div>
  )
}
